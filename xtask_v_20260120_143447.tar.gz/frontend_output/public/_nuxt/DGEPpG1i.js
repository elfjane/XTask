import{e,n,c as a,o as t}from"./Dxm_-M1K.js";const i=e({__name:"index",setup(o){return n("/admin/users"),(r,s)=>(t(),a("div",null,"Redirecting..."))}});export{i as default};
